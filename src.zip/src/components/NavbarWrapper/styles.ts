import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(238, 204, 215, 1)",
  },
  content: {
    flex: 1,
    paddingTop: 80,
  },
});
